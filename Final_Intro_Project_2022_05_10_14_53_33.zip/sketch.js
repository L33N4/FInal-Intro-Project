let rand
let button
let result
let names = ["Jarvis", "Lexsey,", "Sydney", "Lucie", "Max", "Pross", "Holden", "Spencer", "Atlas", "Dante", "Ahmed", "Riley", "Emma", "Maria", "Nate", "Ronald", "John", "Roger", "Connor", "Ryker", "Charles", "David", "Alia", "Catherine", "Maria", "Hadley", "Eli", "Ronald", "Luthor", "Barry", "Aris", "Oliver", "Thea", "Jessica", "Jones", "Byron"]
let = 0
function setup() {
  
}